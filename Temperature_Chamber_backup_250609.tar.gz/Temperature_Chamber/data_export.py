# https://meticulousdev.tistory.com/entry/Python-%ED%95%A8%EC%88%98-%ED%98%B8%EC%B6%9C-%ED%9A%9F%EC%88%98-%EA%B3%84%EC%82%B0-%EC%8B%9C-%EC%95%8C%EC%95%84%EB%91%AC%EC%95%BC%ED%95%98%EB%8A%94-Local-Enclosing-Global-and-Built-in-scopes-LEGB-%EA%B7%9C%EC%B9%99

import csv
import json
from datetime import datetime, timedelta
import time
import serial
import maze
import re

cnt_time = [0]
cnt_count = [0]
pre_time = 0

sensor = maze.Sensor('test.json')

# def write_every_n_miliseconds(file_name, minutes, temp_serial: serial.Serial):
def write_every_n_miliseconds(file_name, minutes):
    global pre_time
    f = open(file_name, 'a')
    wr = csv.writer(f)
    now = datetime.now()
    #print(now)
    next_time = now + timedelta(minutes=minutes, milliseconds=555)
    #print(next_time)
    print('csv writing start')

    while True:
        startTime = round(datetime.utcnow().timestamp() * 1000)
        if (startTime - pre_time >= 10):
            cnt_time[0] += 1
            if (cnt_time[0] == 1):
                print(cnt_time, datetime.now())
            pre_time = startTime
            now_time = round(time.time(), 3)
            # temp_serial.write(b"1")
            # current_temp = float(temp_serial.readline().decode("utf-8").strip())
            # temp_serial.write(b"1")
            # print(temp_serial.readline().decode("utf-8").strip())
            # wr.writerow([*cnt_time, *sensor.get(), now_time, current_temp])

        now_ = datetime.now() #꼭 시간이 되어야만 멈출래? 음.. trial 시간이 정해져 있다고 하면 이게 의미 있긴 하지. 일단 뭐 test로 하는 거니까 줄여 놓는 걸로.
        if now_>next_time:
            print('data_export')
            print(now_)
            break

    f.close()



# if __name__ == "__main__":
#     df = {
#     'Trial' : [0, 0, 0, 1, 1, 1, 2, 2, 2],
#     'Position' : ['l', 'm', 'r', 'l', 'm', 'r', 'l', 'm', 'r'],
#     'Length' : [0, 200, 0, 0, 200, 0, 0, 200, 0],
#     'Width' : [30, 30, 30, 30, 30, 30, 30, 30, 30],
#     'Thickness' : [None, None, None, None, None, None, None, None, None],
#     'Color' : [(255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255)],
#     'Poked Site' : [] }
    
#     TrialData2SCV("home/pi/JJH/result/test0001", df)
