import json
from typing import Set
import pygame
import os
import RPi.GPIO as GPIO #general purpose Input/Output
import time
import random
import serial

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

df = {'Trial':[], 'Position':[],'Length':[], 
        'Width':[],'Thickness':[],'Color':[], 'Poked Site':[]}

class NoneChoiceError(Exception):
    pass
class NoDataFrame(Exception):
    pass

class Display:
    def __init__(self, dir):
        # load file
        with open (dir, "r") as config: 
            data = json.load(config)
            self.screen = pygame.display.set_mode((data['display']['width'],data['display']['height']), pygame.NOFRAME)
            self.screen.fill((0, 0, 0))
            pygame.mouse.set_visible(False)
            #self.img = pygame.image.load(data['directory']['blank'])

    
    def show(self, state = []):
        if len(state) == 0:
            self.screen.fill((0, 0, 0))
            pygame.display.update()
        else:
            for i in state:
                # if i =='l':
                #     self.screen.blit(self.img, (35, 200))
                # elif i =='r':
                #     self.screen.blit(self.img, (575, 200))
                # elif i =='m':
                #     self.screen.blit(self.img, (305, 200))
                if i =="w":
                    self.screen.fill((255, 255, 255))
                elif i =='g':
                    self.screen.fill((128,128,128))
                elif i == "dg":
                    self.screen.fill((64,64,64))
            pygame.display.flip()

    def draw_square(self, position, color, side, base=50):
        # Width of one third of the screen
        third_width = self.screen.get_width() // 3
        
        # Determine the x position based on the specified position
        if position == 'left':
            x = (third_width - side) // 2  # Center in the first third
        elif position == 'center':
            x = (self.screen.get_width() - side) // 2  # Center in the middle
        else:  # 'right'
            x = 2 * third_width + (third_width - side) // 2  # Center in the last third
        
        # Position the square 50 pixels above the bottom of the screen
        y = self.screen.get_height() - side - base
        
        # Drawing the square
        pygame.draw.rect(self.screen, color, (x, y, side, side))
        
        return pygame.Rect(x, y, side, side)  # Return the rect for updating

    def draw_bar(self, length, position, width=150, thickness=None, color=(255, 255, 255), base= 450):
        '''
        This function draws a bar among left, middle, and right
        with input length, width, and type

        Args:
            screen: screen instance after basic setting 
            length(int, float): length of the bar
            position(str): choose to write among "l", "m", and "r",
                otherwise do not display anything
            width(int, float): width of the bar, default is 30
            thickness: thickness of the boundary of the bar.
                default setting is None.
            color(tuple, int): RGB color, default setting is white
        '''
        base = base
        rect = None  # This will store the rectangle to update

        if position == "l" and length != 0:
            rect = pygame.Rect(135-width/2, base-length, width, length)
        elif position == "m" and length != 0:
            rect = pygame.Rect(400-width/2, base-length, width, length)
        elif position == "r" and length != 0:
            rect = pygame.Rect(665-width/2, base-length, width, length)

        if rect is not None:
            if thickness is None:
                pygame.draw.rect(self.screen, color, rect)
            else:
                pygame.draw.rect(self.screen, color, rect, thickness)
            pygame.display.update(rect)

    def draw_rect(self, position, height=200, width=200,
                thickness=None, color=(255, 255, 255), base = 320):
        '''
        This function draws a bar among left, middle, and right
        with input length, width, and type

        Args:
            screen: screen instance after basic setting 
            length(int, float): length of the bar
            position(str): choose to write amoung "l", "m", and "r",
                otherwise do not display anything
            width(int, float): width of the bar, default is 30
            thickness: thickness of the boundary of the bar.
                default setting is None.
            color(tuple, int): RGB color, default setting is white
        '''
        base = base #470
        if thickness is None:
            if position == "l" and height != 0:
                pygame.draw.rect(self.screen, color,
                            pygame.Rect(135-width/2, base-height, width, height))
                
            elif position == "m" and height != 0:
                pygame.draw.rect(self.screen, color,
                                pygame.Rect(400-width/2, base-height, width, height))
                
            elif position == "r" and height != 0:
                pygame.draw.rect(self.screen, color,
                                pygame.Rect(665-width/2, base-height, width, height))
                
            else:
                pass
        else:
            if position == "l" and height != 0:
                pygame.draw.rect(self.screen, color,
                                pygame.Rect(150-width/2, base-height, width, height),
                                thickness)
                
            elif position == "m" and height != 0:
                pygame.draw.rect(self.screen, color,
                                pygame.Rect(400-width/2, base-height, width, height),
                                thickness)
                
            elif position == "r" and height != 0:
                pygame.draw.rect(self.screen, color,
                                pygame.Rect(650-width/2, base-height, width, height),
                                thickness)
                
            else:
                pass
        pygame.display.flip()
    
    def wrong_screen(self, side=150, p = (400, 400)):
        p1 = p
        p2 = (p[0] - side/2, p[1] + side * 3**0.5 /2)
        p3 = (p[0] + side/2, p[1] + side * 3**0.5 /2)

        pygame.draw.polygon(self.screen, (255, 255, 0), [p1, p2, p3])
        pygame.display.update()

    


    def display_bars(self, len_ls, width_ls, th_ls=[None, None, None],
         c_ls=[(255, 255, 255), (255, 255, 255), (255, 255, 255)]):
        '''
        This function can display multiple bars with different setting.

        Args:
            N_trial: number of trial
            len_ls: (list,3)list of length
            width_ls: (list,3)list of width, default is 30
            th_ls: (list,3)list of thickness, default is None
            c_ls: (list,3)list of color code, default is (255, 255, 255)  

        Return:
            rows        
        '''
        
        posit_code = ["l", "m", "r"]

        for i in range(3):
            self.draw_bar(len_ls[i], posit_code[i], width= width_ls[i],
                thickness=th_ls[i], color=c_ls[i]) #self.screen을 맨 앞 인수로 추가하는 실수 동일하게 발생
            # Add new element to the list of each value of df
            
        pygame.display.update()
        


    def display_temp_cue(self, temp):
        hot = pygame.image.load('Hot.png')
        cold = pygame.image.load('Cold.png')

        # Scale images if they're not exactly 200x200
        hot = pygame.transform.scale(hot, (200, 200))
        cold = pygame.transform.scale(cold, (200, 200))

        # Calculate positions
        third_width = 800 // 3
        hot_x = (third_width - 200) // 2  # Center in first third
        cold_x = third_width + (third_width - 200) // 2  # Center in second third
        image_y = (480 - 200) // 2  # Vertically center

        if temp == "hot":
            self.screen.blit(hot, (hot_x, image_y))
        elif temp == "cold":
            self.screen.blit(cold, (cold_x, image_y))
        pygame.display.flip()

    def display_temp_both(self):
        hot = pygame.image.load('Hot.png')
        cold = pygame.image.load('Cold.png')

        # Scale images if they're not exactly 200x200
        hot = pygame.transform.scale(hot, (200, 200))
        cold = pygame.transform.scale(cold, (200, 200))

        # Calculate positions
        third_width = 800 // 3
        hot_x = (third_width - 200) // 2  # Center in first third
        cold_x = third_width + (third_width - 200) // 2  # Center in second third
        image_y = (480 - 200) // 2  # Vertically center

        self.screen.blit(hot, (hot_x, image_y))
        self.screen.blit(cold, (cold_x, image_y))
        pygame.display.flip()

    def erase_temp_cue(self, temp):
         # Calculate positions (same as in display_temp_cue)
        third_width = 800 // 3
        hot_x = (third_width - 200) // 2
        cold_x = third_width + (third_width - 200) // 2
        image_y = (480 - 200) // 2

        # Create a rectangle to cover the image
        cover_rect = pygame.Rect(0, 0, 200, 200)

        if temp == "hot":
            cover_rect.topleft = (hot_x, image_y)
        elif temp == "cold":
            cover_rect.topleft = (cold_x, image_y)

        # Fill the rectangle with the background color
        # Assuming the background is white, change as needed
        self.screen.fill((0, 0, 0), cover_rect)
        
        # Update the display
        pygame.display.update(cover_rect)
        
            
    
class Sensor:
    '''
    This class assgins pin positions for inputs of changed value recognized by sensor and controls inputs.
    We can use this class by storing the detected value in some variables and using it in other lines of code.
    '''
    def __init__(self, dir):
        with open (dir, "r") as config:
            data = json.load(config)
            self.reward = data["GPIO"]["nose_poke_reward"] # pin number #어디지? 이건 건석쌤한테 물어봐야 될 거 같은데
            self.left = data["GPIO"]["nose_poke_left"]
            # self.center = data["GPIO"]["nose_poke_center"]
            self.right = data["GPIO"]["nose_poke_right"]
        GPIO.setup(self.reward, GPIO.IN, pull_up_down = GPIO.PUD_DOWN) # GPIO.PUD_DOWN :direction of resistance == button pressed means True
        GPIO.setup(self.left, GPIO.IN, pull_up_down = GPIO.PUD_DOWN)
        # GPIO.setup(self.center, GPIO.IN, pull_up_down = GPIO.PUD_DOWN)
        GPIO.setup(self.right, GPIO.IN, pull_up_down = GPIO.PUD_DOWN)
    def get(self):
        '''
        This method returns detected value in reward port, and three poking hole: left, center, and right.
        '''
        # return (GPIO.input(self.reward), GPIO.input(self.left), GPIO.input(self.center), GPIO.input(self.right)) 
        return (GPIO.input(self.reward), GPIO.input(self.left), 0, GPIO.input(self.right)) 
    



        
class Reward:
    '''
    This class assgins pin positions for outputs and controls outputs such as motor controling the mass of reward and LED.
    '''
    def __init__(self, dir):
        with open (dir, "r") as config:
            self.data = json.load(config)
            GPIO.setup (self.data["GPIO"]["reward_motor"], GPIO.OUT, initial = GPIO.LOW) 
            GPIO.setup (self.data["GPIO"]["reward_led"], GPIO.OUT, initial = GPIO.LOW)
            GPIO.setup (self.data["GPIO"]["wrong_led"], GPIO.OUT, initial = GPIO.LOW)
    def give(self, duration):
        '''
        This method controls the amount of reward by operating the motor for 'duration' 
        
        Args:
            duration
        '''
        RG_time = time.time()
        GPIO.output(self.data["GPIO"]["reward_motor"], GPIO.HIGH)
        while True: 
            if time.time() - RG_time >= duration:
                break
        GPIO.output(self.data["GPIO"]["reward_motor"], GPIO.LOW)
    def light(self, yes): 
        '''
        This method turns on LED when the boolean parameter is True.

        Args:
            yes(Boolean)
        '''
        if yes == True: 
            GPIO.output(self.data["GPIO"]["reward_led"], GPIO.HIGH)
        else:
            GPIO.output(self.data["GPIO"]["reward_led"], GPIO.LOW)

    def wrong(self, yes):
        '''
        This method turns on wrong LED when mouse choose wrong poking port

        Args:
            yes(Boolean)
        '''
        if yes == True: 
            GPIO.output(self.data["GPIO"]["wrong_led"], GPIO.HIGH)
        else:
            GPIO.output(self.data["GPIO"]["wrong_led"], GPIO.LOW)

class Photometry:
    def __init__(self, dir):
        with open (dir, "r") as config:
            self.data = json.load(config)
            self.fp1 = self.data["GPIO"]["BNC1"]
            self.fp2 = self.data["GPIO"]["BNC2"]
            self.fp3 = self.data["GPIO"]["BNC3"]
            self.fp4 = self.data["GPIO"]["BNC4"]
        GPIO.setup(self.fp1, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(self.fp2, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(self.fp3, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(self.fp4, GPIO.OUT, initial=GPIO.LOW)

    def FP1_on(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp1, GPIO.HIGH)
            fp_time = round(time.time(), 3)
            return fp_time
    
    def FP1_off(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp1, GPIO.LOW)
            fp_time = round(time.time(), 3)
            return fp_time
    
    def FP2_on(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp2, GPIO.HIGH)
            fp_time = round(time.time(), 3)
            return fp_time

    def FP2_off(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp2, GPIO.LOW)
            fp_time = round(time.time(), 3)
            return fp_time
    
    def FP3_on(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp3, GPIO.HIGH)
            fp_time = round(time.time(), 3)
            return fp_time

    def FP3_off(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp3, GPIO.LOW)
            fp_time = round(time.time(), 3)
            return fp_time
    
    def FP4_on(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp4, GPIO.HIGH)
            fp_time = round(time.time(), 3)
            return fp_time
    
    def FP4_off(self, on=False):
        if on == False:
            fp_time = round(time.time(), 3)
            return fp_time
        else:
            GPIO.output(self.fp4, GPIO.LOW)
            fp_time = round(time.time(), 3)
            return fp_time

class Pelier_module:
    def __init__(self, dir):
        self.ser = serial.Serial('/dev/arduino', 115200, timeout=1)

    def set_target_temperature(self, target_temp):
        self.ser.write(f"1,{target_temp}".encode('utf-8'))
        return
    
    def stop(self):
        self.ser.write(f"0,0".encode('utf-8'))
        return
    
    def measure_temp(self):
        self.ser.write(f"2,0".encode('utf-8'))
        while self.ser.in_waiting == 0:
            print("ASD")
            pygame.time.wait(500)
            pass
        line = self.ser.readline().decode('utf-8').strip()
        temps = [float(string) for string in line.split(',') if string != '']
        average = 0
        for temp in temps:
            average += temp
        return average / len(temps)

    def get_current_target_temperature(self):
        self.ser.write(f"3,0".encode("utf-8"))
        while self.ser.in_waiting == 0:
            pass
        line = self.ser.readline().decode("utf-8").strip()
        return float(line)

if __name__ == '__main__':
    a = 'abc.json'
    while (1):
        b = int(input("Enter number you want to test\n[0] Display [1] Reward [2] Sensor [3] Exit\n"))
        if (b == 0):
            instance = Display(a)
            while (1):
                c = input("Enter screen location. To end enter 'e'\n").split(" ")
                if 'e' in c:
                    break
                if c == ['']: # this part is just for test
                    instance.show()
                instance.show(c)
        elif b == 1:
            instance = Reward(a)
            while (1):
                c = input("Enter number you want to test\n[0] reward led [1] reward port [2] exit \n")
                if c == "0":
                    while (1):
                        on = input("If you want to turn on led enter '1', to turn off enter '0', to exit enter 'e'")
                        if on == "0":
                            instance.light(False)
                        elif on == "1":
                            instance.light(True)
                        elif on == 'e':
                            break
                        else:
                            print("wrong input, please try again\n")
                elif c == "1":
                    while (1):
                        duration = input("Enter reward duration you want to give. To end Enter 'e'")
                        if duration == 'e':
                            break
                        instance.give(float(duration))
                        print(str(duration) + "s given")
                elif c == "2":
                    break
                else:
                    print("Wrong input. Please try again\n")
        elif b == 2:
            instance = Sensor(a)
            while (1):
                c = input("If you want to get data, enter '1'. To exit enter '2'")
                if c == "1":
                    print(instance.get())
                elif c == '2':
                    break
                else:
                    print("wrong input please try again\n")
        elif b == 3:
            break
        else:
            print("Wrong input")


