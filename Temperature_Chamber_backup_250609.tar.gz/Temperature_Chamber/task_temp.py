import maze
import time
import json
import multiprocessing
from multiprocessing import freeze_support
import random
import threading
import sys
import cv2
import csv
import os
import math
import pygame

# # maze에서 사용한 library를 다 써야하는게 아닌가? 
# import pandas as pd
# RPi.GPIO as GPIO
# import os
# import pygame

class Task:
    def __init__(self, json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouseid, session): # file_trialdata
        with open (json_dir, "r") as config: #import data
            self.data = json.load(config)
        self.count_limit = self.data["trial"] 
        self.screen = maze.Display(json_dir) 
        self.sensor = maze.Sensor(json_dir)
        self.peltier = maze.Pelier_module(json_dir)
        pygame.time.wait(2000) # 아두이노 기다리기
        self.reward = maze.Reward(json_dir) 
        self.FP = maze.Photometry(json_dir)
        self.file_trialdata = TrialData_file_name # file format can be decided in the task code.
        self.mouseid = mouseid #
        self.trainingstep = session.split("_")[1] #
        self.day = int(session.split("_")[0].split("d")[1]) #
        self.delay = 0.5

        try:
            print("connecting camera")
            self.cap = cv2.VideoCapture(0)
            self.cap.set(cv2.CAP_PROP_FPS, 10)
            
            width = int(self.cap.get(3))
            height = int(self.cap.get(4))
            fourcc = cv2.VideoWriter_fourcc(*'DIVX')
            fps = self.cap.get(cv2.CAP_PROP_FPS)  # Set the desired FPS
            self.out = cv2.VideoWriter(Video_file_name, fourcc, fps, (width, height))
            
            # Create the timestamp file and write the header
            self.timestamp_file = FrameTime_file_name
            os.makedirs(os.path.dirname(self.timestamp_file), exist_ok=True)
            with open(self.timestamp_file, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['Frame', 'Timestamp'])
        except:
            print("camera connecting failed")
            return
    def viedeo_record(self, *args):
        frame_count = 0
        while True:
            ret, frame = self.cap.read()
            if not ret:
                print("Error on reading video")
                break
            
            # Get the current Unix timestamp with decimal places
            unix_timestamp = time.time()
            # Format the Unix timestamp as a string with decimal places
            timestamp_str = f"{unix_timestamp:.3f}"
            # Add the formatted timestamp to the frame
            cv2.putText(frame, timestamp_str, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            
            # Write the timestamp and frame count to the CSV file
            with open(self.timestamp_file, 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([frame_count, f"{unix_timestamp:.3f}"])
            
            frame_count += 1
            
            self.out.write(frame)
            if args[0]():
                break
    def task(self):
        pass
    def run(self):
        freeze_support()
        thread_stop = False
        task_proc = multiprocessing.Process(target=self.task)
        video_proc = threading.Thread(target = self.viedeo_record, args = (lambda: thread_stop, ))
        initial = time.time()
        task_proc.start()
        video_proc.start()
        task_proc.join(float(self.data["min"]) * 60)
        print("done")
        thread_stop = True
        video_proc.join()
        task_proc.kill()
        self.cap.release()
        self.out.release()
        if time.time() - initial > self.data["min"] * 60: #최대 시간이.. 걸린다. 
            print("Time limit reached\nTerminating")
    
    # LED + Reward(amount)
    def LED_Reward(self, amount, FP_on=False):
        self.reward.light(True)
        self.reward.give(amount) # Not determined
        print("reward has given")
        RG_time = round(time.time(), 3)
        fp_reward_on = self.FP.FP3_on(on=FP_on)
        if amount > 0:
            rp_flag=0
            while True:
                current_sensor = self.sensor.get()
                if current_sensor[0]==1 and rp_flag==0:
                    RT_time = round(time.time(), 3)
                    fp_reward_off = self.FP.FP3_off(on=FP_on)
                    print("Reward_on")
                    while True:
                        if self.sensor.get()[0] == 0:
                            rp_flag = 1
                            print("Reward_off")
                            break
                if rp_flag==1:
                    break
        else:
            RT_time = round(time.time(), 3)
            fp_reward_off = self.FP.FP3_off(on=FP_on)
        self.reward.light(False)
            
        return RG_time, RT_time, fp_reward_on, fp_reward_off

    def Wrong_LED(self, screen=True):
        wrongLED_on = round(time.time(), 3)
        self.reward.wrong(True)
        if screen:
            self.screen.wrong_screen(side=200, p = (400, 200))

        print("wrong choice")
        while True:
            if time.time() - wrongLED_on >= 5:
                break
        self.reward.wrong(False)
        wrongLED_off = round(time.time(), 3)
        return wrongLED_on, wrongLED_off    

    def sensor2lmr_init(self, choice_tuple, cue_time, timeout=False, FP_on=True):
        current_sensor = self.sensor.get()
        if sum(current_sensor[1:])>=1 and sum(choice_tuple[1:])==0:
            if current_sensor[1] == 1 and choice_tuple[1] == 0:
                choice_tuple[1] = 1
                poke_pos = 'l'
                poke_time = round(time.time(), 3)
                print("l in")
                print(choice_tuple)
                while True:
                    if self.sensor.get()[1] == 0 and choice_tuple[1] == 1:
                        choice_tuple[1] = 0
                        print("l out")
                        break
            elif current_sensor[2] == 1 and choice_tuple[2] == 0:
                self.screen.show() ##
                choice_tuple[2] = 1
                poke_pos = 'm'
                poke_time = round(time.time(), 3)
                print("m in")
                while True:
                    if self.sensor.get()[2] == 0 and choice_tuple[2] == 1:
                        choice_tuple[2] = 0
                        print("m out")
                        break
            elif current_sensor[3] == 1 and choice_tuple[3] == 0:
                choice_tuple[3] = 1
                poke_pos = 'r'
                poke_time = round(time.time(), 3)
                print("r in")
                while True:
                    if self.sensor.get()[3] == 0 and choice_tuple[3] == 1:
                        choice_tuple[3] = 0
                        print("r out")
                        break
                
            return choice_tuple, poke_pos, poke_time
        else:
            return choice_tuple,

    # Initiation
    def Initiation(self, init_delay=True):
        print("Start Initiation")
        self.screen.draw_bar(480, "m", width=266, thickness=None, color=(255, 255, 255), base= 480)
        init_on = round(time.time(), 3)
        print("Initiation on")
        choice_tuple=[0, 0, 0, 0]
        while True:
            poke_result= self.sensor2lmr_init(choice_tuple, init_on, timeout=False)
            if len(poke_result) == 3:
                # self.screen.draw_bar(480, "m", width=266, thickness=None, color=(0,0,0), base= 480)
                if poke_result[1] == "m":
                    init_off=poke_result[2]
                    break
                else:
                    self.screen.draw_bar(480, "m", width=266, thickness=None, color=(255, 255, 255), base= 480)
        # self.screen.show()
        # if init_delay:
        #     while True:
        #         if time.time() - init_off >= self.delay:
        #             break        

        return init_on, init_off

    def Initiation_reward(self, REWARD=True):
        print("Start Initiation")
        self.screen.show(state = ["w"])
        if REWARD == True:
            self.reward.give(0.01)
        init_reward_given = round(time.time(), 3)
        print("Free reward has been given")

        # To protect reward port sensor misworking and confirm the sensor value is changed by mouse
        rp_flag=0
        while True:
            current_sensor = self.sensor.get()
            if current_sensor[0]==1 and rp_flag==0:
                init_reward_taken = round(time.time(), 3)
                print("Reach magazine")
                while True:
                    if self.sensor.get()[0] == 0:
                        rp_flag = 1
                        print("Initiation_off")
                        break
            if rp_flag == 1:
                break
           
        self.screen.show()

        while True:
            if time.time() - init_reward_taken >= 1:
                break

        return init_reward_given, init_reward_taken


    def sensor2lmr(self, choice_tuple, cue_time, timeout=False, loop=True, FP_on=False):
        if loop == True:
            while True:
                if self.sensor.get()[1] == 1 and choice_tuple[1] == 0:
                    self.screen.show()
                    choice_tuple[1] = 1
                    poke_pos = 'l'
                    poke_time = round(time.time(), 3)
                    print("l in")
                    print(choice_tuple)
                    while True:
                        if self.sensor.get()[1] == 0 and choice_tuple[1] == 1:
                            choice_tuple[1] = 0
                            print("l out")
                            break
                    break
                elif self.sensor.get()[2] == 1 and choice_tuple[2] == 0:
                    self.screen.show()
                    choice_tuple[2] = 1
                    poke_pos = 'm'
                    poke_time = round(time.time(), 3)
                    print("m in")
                    while True:
                        if self.sensor.get()[2] == 0 and choice_tuple[2] == 1:
                            choice_tuple[2] = 0
                            print("m out")
                            break
                    break
                elif self.sensor.get()[3] == 1 and choice_tuple[3] == 0:
                    self.screen.show()
                    choice_tuple[3] = 1
                    poke_pos = 'r'
                    poke_time = round(time.time(), 3)
                    print("r in")
                    while True:
                        if self.sensor.get()[3] == 0 and choice_tuple[3] == 1:
                            choice_tuple[3] = 0
                            print("r out")
                            break
                    break
                elif timeout==True and (time.time() - cue_time) >= 30:
                    
                    poke_pos = "n"
                    print("30 sec passed")
                    poke_time = round(time.time(), 3)
                    break

            return choice_tuple, poke_pos, poke_time
        else:
            current_sensor = self.sensor.get()
            if sum(current_sensor[1:])>=1 and sum(choice_tuple[1:])==0:
                self.screen.show()
                if current_sensor[1] == 1 and choice_tuple[1] == 0:
                    choice_tuple[1] = 1
                    poke_pos = 'l'
                    poke_time = round(time.time(), 3)
                    print("l in")
                    print(choice_tuple)
                    while True:
                        if self.sensor.get()[1] == 0 and choice_tuple[1] == 1:
                            choice_tuple[1] = 0
                            print("l out")
                            break
                elif current_sensor[2] == 1 and choice_tuple[2] == 0:
                    choice_tuple[2] = 1
                    poke_pos = 'm'
                    poke_time = round(time.time(), 3)
                    print("m in")
                    while True:
                        if self.sensor.get()[2] == 0 and choice_tuple[2] == 1:
                            choice_tuple[2] = 0
                            print("m out")
                            break
                elif current_sensor[3] == 1 and choice_tuple[3] == 0:
                    choice_tuple[3] = 1
                    poke_pos = 'r'
                    poke_time = round(time.time(), 3)
                    print("r in")
                    while True:
                        if self.sensor.get()[3] == 0 and choice_tuple[3] == 1:
                            choice_tuple[3] = 0
                            print("r out")
                            break
                   
                return choice_tuple, poke_pos, poke_time
            else:
                return choice_tuple,

            
   
             

            

    def TrialData2CSV2(self, directory, filename, row, col):
        '''
        This function write csv by adding new row if it exists. If not, than create new directory and file
        Args:
            directory
            filename
            row
            col
        '''

        if not os.path.isdir(directory):
            os.makedirs(directory)
        
        if not os.path.exists(filename):
            with open(filename, "w") as outfile:
                writer = csv.writer(outfile)
                writer.writerow(col)
        
        with open(filename, "a") as outfile:
            writer = csv.writer(outfile)
            writer.writerow(row)
    
    def pretraining_1(self, Num_trial=60):
        print("Start pretraining strage 1 (traing reward site)")
        #data
        file_name_td = self.file_trialdata+"_trial-wise.csv"
        directory = os.path.dirname(file_name_td)
        
        col_name_td = ['mouseID', 'Day','Task', 'Trial', 'Start','RewardGiven', 'RewardTaken', 'ITI.1', 'ITI.0', 'End', 'GivenReward', 'Photometry_time']
       
        start_Ex = round(time.time(), 3)
        total_volume = 0
        i = 0
        
        # process
        while True: # self.data["trial"] = 30
            i += 1                
            print("initiating #{} iteration".format(i))
            print()
            init_on = round(time.time(), 3)
            print('given reward 200')

            print()
            self.screen.show()
            l = 200
            # Reward depending on length of bar and probability
            volume = l/20 #2.6**(l/50)
            t = (volume + 4.603)/261.1
            total_volume += volume
            RG_time, RT_time, fp_reward_on, fp_reward_off = self.LED_Reward(t) # intended 2 sec LED turn on !!! 
            givenReward = volume
            
            #report
            print()
            print("<< Report >>")
            print(f"length: {l}")
            print(f"amount:", volume)
            print(f"Left water amount: {1000 - total_volume - (i+1)*2.5}")
            print()

            # ITI
            print('ITI start')
            iti_on = round(time.time(), 3)
            while True:
                if time.time() >= (iti_on + 20):
                    break
            iti_off = round(time.time(), 3)
            print("ITI end")
            end_Ex = round(time.time(), 3)
            print(f"Experimental time: {end_Ex - start_Ex}")
            fp_time_lst = [fp_reward_on, fp_reward_off]

            row_td = [self.mouseid, self.day, self.trainingstep, i+1, start_Ex, RG_time, RT_time, iti_on, iti_off, givenReward, fp_time_lst]

            self.TrialData2CSV2(directory, file_name_td, row_td, col_name_td)
            
            print("---------------------------------------")
            print()
            
            # update trial time 
            if i>= Num_trial:
                print("The number of Session trials reached maximum. \n Terminating task")
                break
            # Time limit
            if (end_Ex - start_Ex) >= self.data["min_p1"]*60:
                print("Session time reached maximum. \n Terminating task")
                self.screen.show(state = ["g"]) #turn gray
                break

    def pretraining_n(self, stage=2, rewardfunc = "amount", cue_position = ["l", "m"], ITI_duration = 20, trial_lim = 30, FP_on=True):
        #data
        file_name_td = self.file_trialdata+"_trial-wise.csv"
        directory = os.path.dirname(file_name_td)
        col_name_td = ['mouseID', 'Day','Task', 'Trial', "num_collection_trials",
        'Start','Initiation.1', 'Initiation.0', 'Cue.1', 'Cue.0', "Poke",'RewardGiven', 'RewardTaken', 'ITI.1', 'ITI.0','End',
        "length","cue_position", "chosen_pos", "GivenReward","correct", "correct_first", "wrong_first", "correct_notfirst", "wrong_notfirst", "Photometry_time"]
        
        total_volume = 0
        start_Ex = round(time.time(), 3)

        # determine task parameter
        if stage == 2.1:
            print("stage 2.1")
            initiation = False
            late_reward = True
            wrong = "small"
        elif stage == 2.2:
            print("stage 2.2")
            initiation = False
            late_reward = True
            wrong = "ignore"
        elif stage == 2.3:
            print("stage 2.3")
            initiation = False
            late_reward = False
            wrong = "small"
        elif stage == 3:
            print("stage 3")
            initiation = False
            late_reward = False
            wrong = "ignore"
        elif stage == 4:
            print("stage 4")
            initiation = True
            late_reward = False
            wrong = "ignore"
        elif stage == 5:
            print("stage 5")
            initiation = True
            late_reward = False
            wrong = "delay"

        # random generation: image order
        
        # random generation: stimulus position with not 3 consecutive same position.
        position_list = []
        if len(cue_position) == 1:
            for _ in range(80):
                position_list.append("m")
        elif len(cue_position) >= 2:
            for _ in range(80):
                sampled_pos = random.sample(cue_position, 1)[0]
                if len(position_list) >= 2:
                    if position_list[-1] == sampled_pos and position_list[-2] == sampled_pos:
                        poped = cue_position.pop(cue_position.index(sampled_pos))
                        sampled_pos = random.sample(cue_position, 1)[0]
                        cue_position.append(poped)
                position_list.append(sampled_pos)
        print("position list:", position_list)
        
            

        i = 0
        correct_first = 0
        correct_notfirst = 0
        wrong_first = 0
        wrong_notfirst = 0
        num_correction_trial = 0
        correct = 1
        
        
        # process
        while True: 
            running=True #must be in while loop of trial repeat
            i += 1
            if correct == 1:
                position = position_list[i]   
                num_correction_trial = 0
            elif correct == 0:
                num_correction_trial += 1
                print("Correction trial #", num_correction_trial)
                           
            print("initiating #{} iteration".format(i))
            print()

            # Initiation
            if initiation == True:
                init_on, init_off = self.Initiation_reward() # center poke might be needed instead of initation step
                
            else:
                init_on = round(time.time(), 3)
                init_off = init_on
            

            self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
            fp_cue_on = self.FP.FP1_on(on=FP_on)
            cue_on = round(time.time(), 3)
            choice_tuple=[0,0,0,0]
            
            if wrong == "small":

                while running:
                    poke_result = self.sensor2lmr(choice_tuple, cue_on, timeout=late_reward)
                    
                    choice_tuple = poke_result[0]                    
                    
                    if len(poke_result) == 3:
                        fp_poke_on = self.FP.FP2_on(on=FP_on)
                        fp_poke_off = self.FP.FP2_off(on=FP_on)
                        poke_pos = poke_result[1]
                        poke_time = poke_result[2]

                        # poke effect
                        while True: 
                            if time.time() - poke_time >= 1:
                                
                                self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                                break
                                
                        if poke_pos == position:
                            correct = 1
                            volume = 10
                            running=False
                            break
                        else:
                            correct = 1
                            volume = 2.5
                            running=False
                            break

            elif wrong == "ignore":
                
                while running:
                    poke_result = self.sensor2lmr(choice_tuple, cue_on, timeout=late_reward)
                    choice_tuple = poke_result[0]                    
                    
                    if len(poke_result) == 3:
                        poke_pos = poke_result[1]
                        poke_time = poke_result[2]

                        if poke_pos == position:
                            fp_poke_on = self.FP.FP2_on(on=FP_on)
                            fp_poke_off = self.FP.FP2_off(on=FP_on)
                            correct = 1
                            volume = 10
                            running=False

                            # poke effect
                            while True: 
                                if time.time() - poke_time >= 1:
                                    self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                                    break
                            break
                        else:
                            self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                            # poke effect
                            # while True: 
                            #     if time.time() - poke_time >= 1:
                            #         self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                            #         break

            elif wrong == "delay":
                                
                while running:
                    poke_result = self.sensor2lmr(choice_tuple, cue_on, timeout=late_reward)
                    
                    choice_tuple = poke_result[0]                    
                    
                    if len(poke_result) == 3:
                        poke_pos = poke_result[1]
                        poke_time = poke_result[2]

                        if poke_pos == position:
                            fp_poke_on = self.FP.FP2_on(on=FP_on)
                            fp_poke_off = self.FP.FP2_off(on=FP_on)
                            correct = 1
                            volume = 10
                            running=False
                            # poke effect
                            while True: 
                                if time.time() - poke_time >= 1:
                                    self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                                    break
                            break
                        elif poke_pos != position:#  and poke_pos != "m"
                            correct = 0
                            # poke effect
                            # while True: 
                            #     if time.time() - poke_time >= 1:
                            #         self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                            #         break
                            self.Wrong_LED(screen=False)
                            volume = 0
                            length = 0
                            running=False
                            fp_poke_on, fp_poke_off = 0, 0
                            
                            break
                        elif poke_pos == "m":
                            self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                            # poke effect
                            # while True: 
                            #     if time.time() - poke_time >= 1:
                            #         self.screen.draw_bar(50, position, width=100, thickness=None, color=(255, 255, 255))
                            #         break
                            

            time_coef = 81
            residue = 0

            if rewardfunc == 'frequency':
                RG_time, RT_time, f, fp_reward_on, fp_reward_off = self.LED_Reward_freq(length*2, FP_on=FP_on) # intended 2 sec LED turn on !!! 
                volume = 0.01*time_coef*f + residue #chamber depedent parameter..
                total_volume += volume
                givenReward = volume
            elif rewardfunc == 'amount':
                # Reward depending on length of bar and probability  
                t = (volume - residue)/time_coef #chamber depedent parameter..
                total_volume += volume
                RG_time, RT_time, fp_reward_on, fp_reward_off = self.LED_Reward(t, FP_on=FP_on) # intended 2 sec LED turn on !!! 
                givenReward = volume        
            
            #cue off
            self.screen.show()
            fp_cue_off = self.FP.FP1_off(on=FP_on)
            cue_off = round(time.time())

            #report
            if num_correction_trial == 0:
                if correct == 1:
                    correct_first += 1
                else:
                    wrong_first += 1
            else:
                if correct == 1:
                    correct_notfirst += 1
                else:
                    wrong_notfirst += 1

            print()
            print()
            print(f"<< Report of {self.mouseid} in pretraining_{stage}>>")
            print("Time interval")
            print(f"Left water: {1000 - total_volume}")
            print("Correct:", correct)
            print("correct_at_first", correct_first, "/", correct_first + wrong_first, "=", round(correct_first / (correct_first + wrong_first), 3))
            print("total accuracy", correct_first+correct_notfirst, "/", i, "=", round((correct_first+correct_notfirst)/i, 3))
            if (correct_notfirst + wrong_notfirst) > 0:
                print("perservative error", wrong_notfirst, "/", wrong_notfirst + correct_notfirst, "=", round(wrong_notfirst /(wrong_notfirst + correct_notfirst), 3))
            print()
            print()

            # ITI
            print('ITI start')
            iti_on = round(time.time(), 3)
            iti_middle = False
            
            while True:
                # if not iti_middle and time.time() >= (iti_on + ITI_duration/2):
                #     self.screen.show()
                #     fp_cue_off = self.FP.FP1_off(on=FP_on)
                #     cue_off = round(time.time())
                #     print(cue_off - iti_on)
                #     iti_middle = True
                if time.time() >= (iti_on + ITI_duration):
                    break
            fp_time_lst = [fp_cue_on, fp_poke_on, fp_poke_off, fp_reward_on, fp_reward_off, fp_cue_off]
            iti_off = round(time.time(), 3)
            print(iti_off - iti_on)
            print("ITI end")
            end_Ex = round(time.time(), 3)
            print(f"Experimental time: {end_Ex - start_Ex}")

            row_td = [self.mouseid, self.day, self.trainingstep, i, num_correction_trial,
            start_Ex, init_on, init_off, cue_on, cue_off, poke_time, RG_time, RT_time, iti_on, iti_off, end_Ex,
            100, position, poke_pos, givenReward, correct,  correct_first, wrong_first, correct_notfirst, wrong_notfirst, 
            fp_time_lst]

            self.TrialData2CSV2(directory, file_name_td, row_td, col_name_td)
            
            print("---------------------------------------")
            print()

            # Time limit
            if (end_Ex - start_Ex) >= self.data["min"]*60:
                print("Session time reached maximum. \n Terminating task")
                self.screen.show(state = ["g"]) #turn gray
                break
            
            if (correct_first+correct_notfirst) >= trial_lim:#
                print("Correct poke reach maximum times. \n Terminating task")
                self.screen.show(state = ["g"])
                break

    def generate_pairs(self, list_length, min_value, max_value):
        
        pairs = []
        subtractLR = []

        while len(pairs) < list_length:
            small = random.randint(min_value, max_value//3)
            large = random.randint(2*max_value//3, max_value)
            pair = random.sample([small, large], 2)
            subtractLR.append((pair[0]-pair[1])/abs(pair[0]-pair[1]))
            if len(subtractLR) >= 3 and subtractLR[-1] == subtractLR[-2] == subtractLR[-3]:
                pair.reverse()
                subtractLR[-1] = (pair[0]-pair[1])/abs(pair[0]-pair[1])
            pairs.append(tuple(pair))

        return pairs

    def Temperature_Reward(self, initiation=True, current_temp = 0, target_temp = 15, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 30, trial_lim = 30, FP_on=True):
        #data
        file_name_td = self.file_trialdata+"_trial-wise.csv"
        directory = os.path.dirname(file_name_td)  

        col_name_td = ['mouseID', 'Day','Task', 'Trial', "Time", "Event", "Current_Temp", "Target_Temp", "Poke_pos", "Photometry_signal"]      
        
        total_volume = 0
        start_Ex = round(time.time(), 3)
        

        # random generation: image order
        
        # random generation: stimulus position with not 3 consecutive same position.

        i = 0
        cold = 0
        hot = 0
        correct_first = 0
        correct_notfirst = 0
        wrong_first = 0
        wrong_notfirst = 0
        num_correction_trial = 0
        correct = 1

        dt_row = [self.mouseid, self.day, self.trainingstep, i, start_Ex, "Start", current_temp, target_temp, 'n', 'n']
        self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
        
        
        # process
        while True: 
            running=True #must be in while loop of trial repeat
            i += 1
                           
            print("initiating #{} iteration".format(i))
            print()

            # Initiation
            if initiation == True:
                init_on, init_off = self.Initiation_reward() # center poke might be needed instead of initation step
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_on, "Initiation.1", current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_off, "Initiation.0", current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            else:
                init_on = round(time.time(), 3)
                init_off = init_on
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_on, "Initiation.1",current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_off, "Initiation.0",current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            
            print("target_temp:", target_temp)
            self.screen.display_temp_both()
            cue_on = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, cue_on, "Cue.1", current_temp, target_temp, 'n', 'n']
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            choice_tuple=[0,0,0,0]
            
            while running:
                poke_result = self.sensor2lmr(choice_tuple, cue_on)
                choice_tuple = poke_result[0]                    
                
                if len(poke_result) == 3:
                    poke_pos = poke_result[1]
                    poke_time = poke_result[2]
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, poke_time, "PokeTime", current_temp, target_temp, poke_pos,'n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    correct = 1
                    volume = 10
                    running=False
                    break
            
            # Reward
            time_coef = 81
            residue = 0
            # Reward depending on length of bar and probability  
            t = (volume - residue)/time_coef #chamber depedent parameter..
            total_volume += volume
            self.reward.light(True)
            self.reward.give(t) 
            print("reward has given")
            RG_time = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, RG_time, "RewardGiven", current_temp, target_temp, poke_pos,'n'] 
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)

            if poke_pos == 'l':
                print("chose H")
                # self.screen.display_temp_cue("cold")
                hot += 1
                fp_poke_on = self.FP.FP1_on(on=FP_on)
                fp_poke_off = self.FP.FP1_off(on=FP_on)
                if target_temp < max_temp:
                    target_temp += d_temp
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time()), "TempUp", current_temp, target_temp, 'n','n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    for _ in range(d_temp):    
                        fp_poke_on = self.FP.FP3_on(on=FP_on)
                        fp_poke_off = self.FP.FP3_off(on=FP_on)
                        
                        while True:
                            if time.time() - fp_poke_on >= 4:
                                break
                    print(f"target temperature : {target_temp}")
            
                else:
                    print("Target temperature reached max temperature")

            if poke_pos == 'm':
                print("chose C")
                fp_poke_on = self.FP.FP2_on(on=FP_on)
                fp_poke_off = self.FP.FP2_off(on=FP_on)
                # self.screen.display_temp_cue("hot")
                cold += 1
                if target_temp > min_temp:
                    target_temp -= d_temp
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time()), "TempDown", current_temp, target_temp, 'n','n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    for _ in range(d_temp):    
                        fp_poke_on = self.FP.FP4_on(on=FP_on)
                        fp_poke_off = self.FP.FP4_off(on=FP_on)
                        while True:
                            if time.time() - fp_poke_on >= 4:
                                break
                    print(f"target temperature : {target_temp}")

                    # poke effect
                    while True: 
                        if time.time() - poke_time >= 1:
                            break
                else:
                    print("Target temperature reached min temperature")
            self.reward.light(False)
            print("target_temp:", target_temp)
                                  
            
            #cue off
            self.screen.show()
            fp_cue_off = self.FP.FP1_off(on=FP_on)
            cue_off = round(time.time())

            #report
            if num_correction_trial == 0:
                if correct == 1:
                    correct_first += 1
                else:
                    wrong_first += 1
            else:
                if correct == 1:
                    correct_notfirst += 1
                else:
                    wrong_notfirst += 1

            print()
            print()
            print(f"<< Report of {self.mouseid} in Temperature_Reward>>")
            print("Time interval")
            print(f"Left water: {1000 - total_volume}")
            print('hot:', hot)
            print('cold:', cold)
            print()
            print()

            # ITI
            print('ITI start')
            iti_on = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, iti_on, "ITI.1", current_temp, target_temp, 'n','n'] 
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            

            while True:
                # if not iti_middle and time.time() >= (iti_on + ITI_duration/2):
                #     self.screen.show()
                #     fp_cue_off = self.FP.FP1_off(on=FP_on)
                #     cue_off = round(time.time())
                #     print(cue_off - iti_on)
                #     iti_middle = True
                if time.time() >= (iti_on + ITI_duration):
                    break
            iti_off = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, iti_off, "ITI.0", current_temp, target_temp, 'n','n'] 
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            print("ITI end") 
            end_Ex = round(time.time(), 3)
            print(f"Experimental time: {end_Ex - start_Ex}")

            
            
            print("---------------------------------------")
            print()

            # Time limit
            if (end_Ex - start_Ex) >= self.data["min"]*60:
                print("Session time reached maximum. \n Terminating task")
                self.screen.show(state = ["g"]) #turn gray
                break
            
            if (correct_first+correct_notfirst) >= trial_lim:#
                print("Correct poke reach maximum times. \n Terminating task")
                self.screen.show(state = ["g"])
                break

    def Temperature_association(self, temp, initiation=True, reward=True, stay_time = 5, task_time = 30, start_temp = 10, optimal_temp = 30, d_temp = 5, ITI_duration = 30, FP_on=True):
        #data
        file_name_td = self.file_trialdata+"_trial-wise.csv"
        directory = os.path.dirname(file_name_td)  

        col_name_td = ['mouseID', 'Day','Task', 'Trial', "Time", "Event", "Current_Temp", "Target_Temp", "Poke_pos", "Photometry_signal"]      
        
        total_volume = 0
        current_temp = start_temp
        target_temp = start_temp

        start_Ex = round(time.time(), 3)
        

        # random generation: image order
        
        # random generation: stimulus position with not 3 consecutive same position.

        i = 0
        cold = 0
        hot = 0
        correct_first = 0
        correct_notfirst = 0
        wrong_first = 0
        wrong_notfirst = 0
        num_correction_trial = 0
        correct = 1

        dt_row = [self.mouseid, self.day, self.trainingstep, i, start_Ex, "Start", current_temp, target_temp, 'n', 'n']
        self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)

        stay_on = round(time.time(), 3)
        dt_row = [self.mouseid, self.day, self.trainingstep, i, stay_on, "Stay.1", current_temp, target_temp, 'n', 'n']
        self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
        print("stay on")
        while True: 
            if time.time() - stay_on >= stay_time*60:
                stay_off = round(time.time(), 3)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, stay_off, "Stay.0", current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                print("stay off")
                break
        
        # process
        while True: 
            running=True #must be in while loop of trial repeat
            i += 1
                           
            print("initiating #{} iteration".format(i))
            print()

            # Initiation
            if initiation == True:
                init_on, init_off = self.Initiation_reward() # center poke might be needed instead of initation step
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_on, "Initiation.1", current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_off, "Initiation.0", current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            else:
                init_on = round(time.time(), 3)
                init_off = init_on
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_on, "Initiation.1",current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, init_off, "Initiation.0",current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            
            print("target_temp:", target_temp)
            if temp =="hot":
                self.screen.display_temp_cue("hot")
            elif temp == "cold":
                self.screen.display_temp_cue("cold")
            cue_on = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, cue_on, "Cue.1", current_temp, target_temp, 'n', 'n']
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            choice_tuple=[0,0,0,0]
            
            while running:
                poke_result = self.sensor2lmr(choice_tuple, cue_on)
                choice_tuple = poke_result[0]                    
                
                if len(poke_result) == 3:
                    poke_pos = poke_result[1]
                    poke_time = poke_result[2]
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, poke_time, "PokeTime", current_temp, target_temp, poke_pos,'n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    if temp == "cold":
                        if poke_pos == 'l':
                            self.screen.display_temp_cue("cold")
                        elif poke_pos == 'm':
                            correct = 1
                            volume = 10
                            break
                    elif temp == "hot":
                        if poke_pos == 'm':
                            self.screen.display_temp_cue("hot")
                        elif poke_pos == 'l':
                            correct = 1
                            volume = 10
                            break
                    # Time limit
                if (time.time() - start_Ex) >= task_time*60:
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time(), 3), "End", current_temp, target_temp, 'n','n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    print("Session time reached maximum. \n Terminating task")
                    self.screen.show(state = ["g"]) #turn gray
                    break
            
            if reward:
                # Reward
                time_coef = 81
                residue = 0
                # Reward depending on length of bar and probability  
                t = (volume - residue)/time_coef #chamber depedent parameter..
                total_volume += volume
                self.reward.light(True)
                self.reward.give(t) 
                print("reward has given")
                RG_time = round(time.time(), 3)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, RG_time, "RewardGiven", current_temp, target_temp, poke_pos,'n'] 
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)

            if poke_pos == 'l':
                print("chose H")
                # self.screen.display_temp_cue("cold")
                hot += 1
                fp_poke_on = self.FP.FP1_on(on=FP_on)
                fp_poke_off = self.FP.FP1_off(on=FP_on)
                if target_temp < optimal_temp:
                    target_temp += d_temp
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time()), "TempUp", current_temp, target_temp, 'n','n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    for _ in range(d_temp):    
                        fp_poke_on = self.FP.FP3_on(on=FP_on)
                        fp_poke_off = self.FP.FP3_off(on=FP_on)
                        
                        while True:
                            if time.time() - fp_poke_on >= 4:
                                break
                    print(f"target temperature : {target_temp}")
            
                else:
                    print("Target temperature reached optimal temperature")

            if poke_pos == 'm':
                print("chose C")
                fp_poke_on = self.FP.FP2_on(on=FP_on)
                fp_poke_off = self.FP.FP2_off(on=FP_on)
                # self.screen.display_temp_cue("hot")
                cold += 1
                if target_temp > optimal_temp:
                    target_temp -= d_temp
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time()), "TempDown", current_temp, target_temp, 'n','n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    for _ in range(d_temp):    
                        fp_poke_on = self.FP.FP4_on(on=FP_on)
                        fp_poke_off = self.FP.FP4_off(on=FP_on)
                        while True:
                            if time.time() - fp_poke_on >= 4:
                                break
                    print(f"target temperature : {target_temp}")

                    # poke effect
                    while True: 
                        if time.time() - poke_time >= 1:
                            break
                else:
                    print("Target temperature reached optimal temperature")
            self.reward.light(False)
            print("target_temp:", target_temp)
                                  
            
            #cue off
            self.screen.show()
            fp_cue_off = self.FP.FP1_off(on=FP_on)
            cue_off = round(time.time())

            #report
            if num_correction_trial == 0:
                if correct == 1:
                    correct_first += 1
                else:
                    wrong_first += 1
            else:
                if correct == 1:
                    correct_notfirst += 1
                else:
                    wrong_notfirst += 1

            print()
            print()
            print(f"<< Report of {self.mouseid} in Temperature_Reward>>")
            print("Time interval")
            print(f"Left water: {1000 - total_volume}")
            print('hot:', hot)
            print('cold:', cold)
            print()
            print()

            # ITI
            print('ITI start')
            iti_on = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, iti_on, "ITI.1", current_temp, target_temp, 'n','n'] 
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            

            while True:
                # if not iti_middle and time.time() >= (iti_on + ITI_duration/2):
                #     self.screen.show()
                #     fp_cue_off = self.FP.FP1_off(on=FP_on)
                #     cue_off = round(time.time())
                #     print(cue_off - iti_on)
                #     iti_middle = True
                if time.time() >= (iti_on + ITI_duration):
                    break
            iti_off = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, iti_off, "ITI.0", current_temp, target_temp, 'n','n'] 
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            print("ITI end") 
            end_Ex = round(time.time(), 3)
            print(f"Experimental time: {end_Ex - start_Ex}")

            
            
            print("---------------------------------------")
            print()

            # Time limit
            if (end_Ex - start_Ex) >= task_time*60:
                dt_row = [self.mouseid, self.day, self.trainingstep, i, round(end_Ex, 3), "End", current_temp, target_temp, 'n','n'] 
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                print("Session time reached maximum. \n Terminating task")
                self.screen.show(state = ["g"]) #turn gray
                break
            
    def Temperature_Reversal_Learning(self, stay_time_start=5, task_time=30, stay_time_end=0,start_temp = 10, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 30, FP_on=True):

        #data
        file_name_td = self.file_trialdata+"_trial-wise.csv"
        directory = os.path.dirname(file_name_td)
        
        col_name_td = ['mouseID', 'Day','Task', 'Trial', "Time", "Event", "Current_Temp", "Target_Temp", "Poke_pos", "Photometry_signal"]
        
        choice_tuple=[0,0,0,0]
        start_Ex = round(time.time(), 3)
        i = 0
        current_temp = start_temp
        target_temp = start_temp

        dt_row = [self.mouseid, self.day, self.trainingstep, i, start_Ex, "Start", current_temp, target_temp, 'n', 'n']
        self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)

        stay_on = round(time.time(), 3)
        dt_row = [self.mouseid, self.day, self.trainingstep, i, stay_on, "Stay.1", current_temp, target_temp, 'n', 'n']
        self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
        print("stay on")
        while True: 
            if time.time() - stay_on >= stay_time_start*60:
                stay_off = round(time.time(), 3)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, stay_off, "Stay.0", current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                print("stay off")
                break

        # process
        while True:
            i += 1
            # Update current_temp (not possible yet)
            current_temp = 0 # temperature sensor
            
            self.screen.display_temp_both()
            # if  min_temp < target_temp < max_temp:
            #     self.screen.display_temp_both()
            # elif target_temp <= min_temp:
            #     self.screen.display_temp_cue("hot")
            # elif target_temp >= max_temp:
            #     self.screen.display_temp_cue("cold")
            cue_on = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, cue_on, "Cue.1", current_temp, target_temp, 'n', 'n']
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            print("current_temp:", current_temp )
            print("target_temp:", target_temp)
            choice_tuple=[0,0,0,0]
            
            while True:
                poke_result = self.sensor2lmr(choice_tuple, cue_on, loop=False)
                choice_tuple = poke_result[0]                    
                
                if len(poke_result) == 3:
                    poke_pos = poke_result[1]
                    poke_time = poke_result[2]
                    
                    if poke_pos == "l" or poke_pos == "m":
                        dt_row = [self.mouseid, self.day, self.trainingstep, i, poke_time, "PokeTime", current_temp, target_temp, poke_pos,'n'] 
                        self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                        break
                
                # Time limit
                if (time.time() - start_Ex) >= task_time*60:
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time(), 3), "End", current_temp, target_temp, 'n','n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    print("Session time reached maximum. \n Terminating task")
                    self.screen.show(state = ["g"]) #turn gray
                    break
                           
                      
                
            if poke_pos == 'l':
                print("chose H")
                fp_poke_on = self.FP.FP1_on(on=FP_on)
                fp_poke_off = self.FP.FP1_off(on=FP_on) 
                # self.screen.display_temp_cue("cold")
                if target_temp < max_temp:
                    target_temp += d_temp
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time()), "TempUp", current_temp, target_temp, poke_pos,'n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    for _ in range(d_temp):    
                        fp_poke_on = self.FP.FP3_on(on=FP_on)
                        fp_poke_off = self.FP.FP3_off(on=FP_on)
                        while True:
                            if time.time() - fp_poke_on >= 4:
                                break
                    print(f"target temperature : {target_temp}")

                    # poke effect
                    while True: 
                        if time.time() - poke_time >= 1:
                            break
            
                else:
                    print("Target temperature reached max temperature")

            if poke_pos == 'm':
                print("chose C")
                fp_poke_on = self.FP.FP2_on(on=FP_on)
                fp_poke_off = self.FP.FP2_off(on=FP_on)
                # self.screen.display_temp_cue("hot")
                if target_temp > min_temp:
                    target_temp -= d_temp
                    dt_row = [self.mouseid, self.day, self.trainingstep, i, round(time.time()), "TempDown", current_temp, target_temp, poke_pos,'n'] 
                    self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                    for _ in range(d_temp):    
                        fp_poke_on = self.FP.FP4_on(on=FP_on)
                        fp_poke_off = self.FP.FP4_off(on=FP_on)
                        while True:
                            if time.time() - fp_poke_on >= 4:
                                break
                    print(f"target temperature : {target_temp}")

                    # poke effect
                    while True: 
                        if time.time() - poke_time >= 1:
                            break
            
                else:
                    print("Target temperature reached min temperature")

                # ITI
            print('ITI start')
            iti_on = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, iti_on, "ITI.1", current_temp, target_temp, 'n','n'] 
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            

            while True:
                # if not iti_middle and time.time() >= (iti_on + ITI_duration/2):
                #     self.screen.show()
                #     fp_cue_off = self.FP.FP1_off(on=FP_on)
                #     cue_off = round(time.time())
                #     print(cue_off - iti_on)
                #     iti_middle = True
                if time.time() >= (iti_on + ITI_duration):
                    break
            iti_off = round(time.time(), 3)
            dt_row = [self.mouseid, self.day, self.trainingstep, i, iti_off, "ITI.0", current_temp, target_temp, 'n','n'] 
            self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
            print("ITI end") 
            end_Ex = round(time.time(), 3)
            print(f"Experimental time: {end_Ex - start_Ex}")


            end_Ex = time.time()
            # Time limit
            if (end_Ex - start_Ex) >= task_time *60:
                
                self.screen.show(state = ["g"]) #turn gray
                break

        stay2_on = round(time.time(), 3)
        dt_row = [self.mouseid, self.day, self.trainingstep, i, stay2_on, "Stay2.1", current_temp, target_temp, 'n', 'n']
        self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
        print("stay2 on")
        while True: 
            if time.time() - stay2_on >= stay_time_end*60:
                stay2_off = round(time.time(), 3)
                dt_row = [self.mouseid, self.day, self.trainingstep, i, stay2_off, "Stay2.0", current_temp, target_temp, 'n', 'n']
                self.TrialData2CSV2(directory, file_name_td, dt_row, col_name_td)
                print("stay2 off")
                break    

        print("Session time reached maximum. \n Terminating task")   

    def Temperature_test(self, stay_time_start=5, task_time=30, stay_time_end=0,start_temp = 10, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 30, FP_on=True):
        print("set temp 30.0")
        start_time = time.time()
        self.peltier.set_target_temperature(30.0)
        curr_temp = self.peltier.measure_temp()
        while curr_temp < 29.5:
            print(curr_temp)
            curr_temp = self.peltier.measure_temp()
        print(f"time consumed: {time.time() - start_time}")

        print("set temp 25.0")
        start_time = time.time()
        self.peltier.set_target_temperature(25.0)
        curr_temp = self.peltier.measure_temp()
        while curr_temp > 25.5:
            print(curr_temp)
            curr_temp = self.peltier.measure_temp()
        print(f"time consumed: {time.time() - start_time}")
        print("stop")
        self.peltier.stop()
        return

    
speed_test = 0.25
ITI_test = 20
trial_test = 30
            

class Pretraining_1(Task):
    def task(self):
        self.pretraining_1(Num_trial=60)

class Pretraining_22(Task):
    def task(self):
        self.pretraining_n(stage=2.3,  rewardfunc = "amount", cue_position = ["l", "m"], ITI_duration = ITI_test, trial_lim = trial_test)

class Pretraining_32(Task):
    def task(self):
        self.pretraining_n(stage=3,  rewardfunc = "amount", cue_position = ["l", "m"], ITI_duration = ITI_test, trial_lim = trial_test)

class Pretraining_42(Task):
    def task(self):
        self.pretraining_n(stage=4,  rewardfunc = "amount", cue_position = ["l", "m"], ITI_duration = ITI_test, trial_lim = trial_test)

class Pretraining_5(Task):
    def task(self):
        self.pretraining_n(stage=5, rewardfunc = "amount", cue_position = ["l", "m"], ITI_duration = ITI_test, trial_lim = trial_test)

class TAL10(Task):
    def task(self):
        self.Temperature_association("hot", initiation=False, reward=False, stay_time = 5, task_time = 30, start_temp = 10, optimal_temp = 30, d_temp = 5, ITI_duration = 0, FP_on=True)

class TAL45(Task):
    def task(self):
        self.Temperature_association("cold", initiation=False, reward=False, stay_time = 5, task_time = 30, start_temp = 45, optimal_temp = 25, d_temp = 5, ITI_duration = 0, FP_on=True)



class TRL_start10(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=5, task_time=30, stay_time_end=0, start_temp = 10, max_temp = 45, min_temp = 10, d_temp = 5, ITI_duration = 0, FP_on=True)

class TRL_start45(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=5, task_time=30, stay_time_end=0, start_temp = 45, max_temp = 45, min_temp = 10, d_temp = 5, ITI_duration = 0, FP_on=True)

class TRL_start10_1(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=5, task_time=60, stay_time_end=0, start_temp = 10, max_temp = 45, min_temp = 10, d_temp = 5, ITI_duration = 0, FP_on=True)

class TRL_start45_1(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=5, task_time=60, stay_time_end=0, start_temp = 45, max_temp = 45, min_temp = 10, d_temp = 5, ITI_duration = 0, FP_on=True)

class TRL_start15_2(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=1, task_time=30, stay_time_end=30, start_temp = 15, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 0, FP_on=True)

class TRL_start40_2(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=5, task_time=30, stay_time_end=30, start_temp = 40, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 0, FP_on=True)
class TRL_start15_3(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=5, task_time=30, stay_time_end=30, start_temp = 15, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 0, FP_on=True)

class TRL_start40_3(Task):
    def task(self):
        self.Temperature_Reversal_Learning(stay_time_start=1, task_time=30, stay_time_end=30, start_temp = 40, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 0, FP_on=True)

class TRL_reward_10(Task):
    def task(self):
        self.Temperature_Reward(initiation=True, current_temp = 0, target_temp = 10, max_temp = 45, min_temp = 10, d_temp = 5, ITI_duration = 200, trial_lim = 30, FP_on=True)
                
class TRL_reward_45(Task):
    def task(self):
        self.Temperature_Reward(initiation=True, current_temp = 0, target_temp = 45, max_temp = 45, min_temp = 10, d_temp = 5, ITI_duration = 200, trial_lim = 30, FP_on=True)
            
class TRL_reward_25(Task):
    def task(self):
        self.Temperature_Reward(initiation=True, current_temp = 0, target_temp = 25, max_temp = 45, min_temp = 10, d_temp = 5, ITI_duration = 200, trial_lim = 30, FP_on=True)

class Temperature_test(Task):
    def task(self):
        self.Temperature_test(stay_time_start=1, task_time=30, stay_time_end=30, start_temp = 40, max_temp = 40, min_temp = 15, d_temp = 5, ITI_duration = 0, FP_on=True)

if __name__ =="__main__":
    json_dir = input("Enter your json file\n")
    while (1):
        task = input("""
To start enter number you want to run
    [1] Magazine training
    [2] Center Hole FR1
    [3] Chaining Center to Left and Right
    [4] Responding on Sides Only:
    [5] Responding on Chained Sides Followed by ITI
    [6] Improving and Worsening Delay Discounding
    [7] Worsening and Improving Probability Discounting
    [0] Exit
""")
        if task == "0":
            print("Selected Exit")
            break
        elif task == "1":
            instance = Pretraining_1(json_dir)
            instance.run()
            break
        elif task == "2":
            instance = Pretraining_2(json_dir)
            instance.run()
            break
        elif task == "3":
            instance = Pretraining_3(json_dir)
            instance.run()
            break
        elif task == "4":
            instance = Pretraining_4(json_dir)
            instance.run()
            break
        elif task == "5":
            instance = Length_Amount_Association(json_dir)
            instance.run()
            break
        elif task == "6":
            instance = PastPresentFutureTest(json_dir)
            instance.run()
            break
        else:
            print("Wrong input, please try again\n")
    print("Proccess made an end\nShutting down...\n")
    sys.exit()

