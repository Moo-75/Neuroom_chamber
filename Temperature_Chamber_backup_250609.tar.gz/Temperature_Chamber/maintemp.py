from datetime import datetime
from pytz import timezone
import os
import multiprocessing
import serial
import data_export
from task_temp import *

#dir_ = os.getcwd()

def check_starting(experiment_start, csv_write_dir, mouse_id, session): # add arguement `csv_write_dir`(2022-08-24)
    '''
    This function seems to create file name with the date and time
    '''
    if experiment_start == 'y' or experiment_start == 'Y':
        flag = True
        print('flag', flag) 
        
    if flag == True:
        experiment_time = datetime.now(timezone('Asia/Seoul'))
        experiment_time_str = experiment_time.strftime("%Y-%m-%d_%H-%M-%S")
        Video_file_name = os.path.join(csv_write_dir,f"Video_{mouse_id}_{session}_{experiment_time_str}.avi")
        TrialData_file_name = os.path.join(csv_write_dir,f"TD_{mouse_id}_{session}_{experiment_time_str}")
        SensorTime_file_name = os.path.join(csv_write_dir,f"Sensor_{mouse_id}_{session}_{experiment_time_str}.csv")
        FrameTime_file_name = os.path.join(csv_write_dir,f"FrameTime_{mouse_id}_{session}_{experiment_time_str}.csv") 
    
    return SensorTime_file_name, Video_file_name, FrameTime_file_name, TrialData_file_name
    
def create_path(csv_write_dir, file_name):
    if os.path.isdir(csv_write_dir):
        f = open(file_name, 'w')
        if os.stat(file_name).st_size == 0:
            # f.write("Time Stamp, Reward, Nose Poke Left, Nose Poke Center, Nose Poke Right, Real time\n")
            f.write("Time Stamp, Reward, Nose Poke Left, Nose Poke Center, Nose Poke Right, Real time, Temperature\n")
        print(f)
        f.close()
    else:
        os.makedirs(csv_write_dir)
        f = open(file_name, 'w')
        if os.stat(file_name).st_size == 0:
            # f.write("Time Stamp, Reward, Nose Poke Left, Nose Poke Center, Nose Poke Right, Real time\n")
            f.write("Time Stamp, Reward, Nose Poke Left, Nose Poke Center, Nose Poke Right, Real time, Temperature\n")
        print(f)
        f.close()
    return file_name

if __name__ == '__main__':
    json_dir = input("Please enter your json file :")
    
    with open (json_dir, 'r') as json_:
        data = json.load(json_)
    
    while True:
        protocol = input("Please type protocol (e.g. OBT, TBT): ")
        protocol = "../" + protocol 
        break

    mouse_id = input('Please enter the mouse id : ')
    session = input('Please enter the session (ex. d18_p1) : ')

    while mouse_id == '' or session == '':
        mouse_id = input('Please reenter the mouse id (do not use _ in the name) : ')
        session = input('Please reenter the session : ')
    else:
        experiment_start = input('If the experiment start, press y  ')
    
    print(mouse_id, session)
    print(experiment_start)
    
    csv_write_dir = os.path.join(protocol,mouse_id+"_"+session)
    SensorTime_file_name, Video_file_name, FrameTime_file_name, TrialData_file_name = check_starting(experiment_start, csv_write_dir, mouse_id, session)
    SensorTime_file_name = create_path(csv_write_dir, SensorTime_file_name)
        
    while (1):
        task = input("""
To start enter number you want to run
    [w] reward hole test
    [p1] Pretraining 1 
    [p22] Pretraining 2 
    [p32] Pretraining 3 
    [p42]
    [p5]
    [ta10]
    [ta45]
    [trl10] Temperature Reversal Learning 10/5
    [trl45] Temperature Reversal Learning 45/5
    [trl101] Temperature Reversal Learning 10/ 1 hour
    [trl451] Temperature Reversal Learning 45/ 1 hour
    [trl152] Temperature Reversal Learning 15/ 1 hour
    [trl402] Temperature Reversal Learning 40/ 1 hour
    [BRL_test] Temperature test

    [0] Exit
""")
        # temp_serial = serial.Serial("/dev/ttyACM2", "9600")

        if task == "0":
            print("Selected Exit")
            break
        elif task == "p1":
            instance = Pretraining_1(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "p22":
            instance = Pretraining_22(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "p32":
            instance = Pretraining_32(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "p42":
            instance = Pretraining_42(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "p5":
            instance = Pretraining_5(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break

        elif task == "ta10":
            instance = TAL10(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break

        elif task == "ta45":
            instance = TAL45(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        
        elif task == "trl10":
            instance = TRL_start10(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break

        elif task == "trl45":
            instance = TRL_start45(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "trl101":
            instance = TRL_start10_1(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break

        elif task == "trl451":
            instance = TRL_start45_1(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "trl152":
            instance = TRL_start15_2(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break

        elif task == "trl402":
            instance = TRL_start40_2(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "trl153":
            instance = TRL_start15_3(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break

        elif task == "trl403":
            instance = TRL_start40_3(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "tr10":
            instance = TRL_reward_10(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "tr25":
            instance = TRL_reward_25(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "tr45":
            instance = TRL_reward_45(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"], temp_serial))
            task_.start()
            instance.run()
            task_.join()
            break
        elif task == "BRL_test":
            instance = Temperature_test(json_dir, Video_file_name, FrameTime_file_name, TrialData_file_name, mouse_id, session)
            task_ = multiprocessing.Process(target=data_export.write_every_n_miliseconds, args = (SensorTime_file_name, data["min"]))
            task_.start()
            instance.run()
            task_.join()
        

    
        else:
            print("Wrong input, please try again\n")
    # temp_serial.close()
    print("Proccess made an end\nShutting down...\n")
    sys.exit()
